import os
from flask import Flask, render_template, request
from transformers import pipeline
import torch

app = Flask(__name__)

# 업로드한 사진이 저장될 폴더
UPLOAD_FOLDER = os.path.join("static", "uploads")
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER

# ===== AI 모델 불러오기 =====
device = 0 if torch.cuda.is_available() else -1
print("사용 장치:", "GPU" if device == 0 else "CPU")

classifier = pipeline(
    "image-classification",
    model="google/vit-base-patch16-224",
    device=device,
)


@app.route("/", methods=["GET", "POST"])
def index():
    results = None
    image_path = None

    if request.method == "POST":
        file = request.files.get("image")
        if file and file.filename:
            save_path = os.path.join(app.config["UPLOAD_FOLDER"], file.filename)
            file.save(save_path)

            image_path = "uploads/" + file.filename

            predictions = classifier(save_path, top_k=3)
            results = [
                {"label": p["label"], "score": round(p["score"] * 100, 1)}
                for p in predictions
            ]

    return render_template("index.html", results=results, image_path=image_path)


if __name__ == "__main__":
    app.run(debug=True, port=5000)